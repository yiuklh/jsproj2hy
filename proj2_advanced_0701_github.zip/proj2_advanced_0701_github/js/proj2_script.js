$(function(){
    //Global Variables
    //Create total minutes variable
    var totalBike = 0;
    var totalWalk = 0;
    //Create choice variable
    var choice1 = 0;
    var choice2 = 0; 
    
    //Array for Line 4 stations into objects
    var line4Stns = [
        {
                stnName: 'Sheppard', 
                minBike: 0,
                minWalk: 0
            },
            
        {
                stnName: 'Bayview', 
                minBike: 9,
                minWalk: 26
            },
            
        {
                stnName: 'Bessarion', 
                minBike: 3,
                minWalk: 11
            },
            
        {
                stnName: 'Leslie', 
                minBike: 4,
                minWalk: 8
            },
            
        {
                stnName: 'Don Mills', 
                minBike: 8,
                minWalk: 19
            }
    ];//ends line4 array
    
    
    //<--Advanced Level-->//
    //step1 GET something: station buttons btn class  
    //step2 LISTEN something: button click event
    
    //clicks btn1 means variable choice1 to START
    //clicks btn2 means variable choice2 to STOP
    //Difference bw the two stations is the commute time
    
    //setup event listeners
    $('.main').on("click", ".btn1", function(){
        choice1 = $(this).attr('data-number');
        console.log(choice1);
        
        //parsefloat choice, which is a string, to convert to a number
        var pickStn1 = parseFloat(choice1);
        console.log(pickStn1);
        
        // get text content of choice1
        var stnName1 = $(this).text();
        console.log(stnName1);
    });
    
    $('.main').on("click", ".btn2", function(){
        choice2 = $(this).attr('data-number');
        console.log(choice2);
        
        var pickStn2 = parseFloat(choice2);
        console.log(pickStn2);
        
        var stnName2 = $(this).text();
        console.log(stnName2);
    });
    
    //Key Idea: Put variables at right place   
    //compare functions choice1 and choice2 can calculate their difference which is the total minutes commute
    
    //create another button btnDisplay to display info 
    $('.main').on("click", ".btnInfo",function(){
        
        var stationsToVisit; 
        console.log(choice1, choice2);

        if(choice1 > choice2){
            //slice selects part of an array, and returns new array
            //if choice1 > choice2 then slice forward
            stationsToVisit = line4Stns.slice(choice2, choice1)
            console.log(stationsToVisit);
        } else {
            //if choice2 > choice1 then slice reverse
            stationsToVisit = line4Stns.slice(choice1, choice2)
            console.log(stationsToVisit);
        };
        
        //Codes for calculation
        //add from choice1 + to choice2 = total minutes
        
        //No cumulative adding if multi-clicks btn 
        totalBike = 0;
        totalWalk = 0;

        //loop over each station
        stationsToVisit.forEach(function(line4Stns){
            //Add those values to the total
            totalBike = totalBike + line4Stns.minBike;
            totalWalk = totalWalk + line4Stns.minWalk;
        });
        
        //step3 DO something: Display info 
        //Create new variable to display on screen 
        var sentence = `From ${line4Stns[choice1 - 1].stnName} ,it would takes you ${totalBike} minutes to bike or ${totalWalk} minutes to walk going to ${line4Stns[choice2 - 1].stnName}!`;

        $('.sentence').text(sentence);
        
        console.log(sentence);
    });
     
});//ends document ready